package pobj.tme6;

import javafx.scene.paint.Color;

public class BoundContext implements IContext {

	private int minX, minY, maxX, maxY;
	private boolean first = true;
	
	public int getMinX() {
		return minX;
	}

	public int getMinY() {
		return minY;
	}

	public int getMaxX() {
		return maxX;
	}

	public int getMaxY() {
		return maxY;
	}

	protected void addPoint(int x, int y) {
		if (first) {
			minX = x;
			minY = y;
			maxX = x;
			maxY = y;
			first = false;
		}
		else {
			if (x<minX) minX = x;
			if (y<minY) minY = y;
			if (x>maxX) maxX = x;
			if (y>maxY) maxY = y;
		}
	}

	@Override
	public void drawLine(int x1, int y1, int x2, int y2, Color color) {
		addPoint(x1,y1);
		addPoint(x2,y2);
	}

}
