package pobj.tme6;

import java.util.List;
import java.util.Vector;

public class CommandList implements ICommand {

	private List<ICommand> commands;
	
	public CommandList() {
		commands = new Vector<ICommand>();
	}
	
	public void addCommand(ICommand command) {
		commands.add(command);
	}
	
	@Override
	public void execute(IColorTurtle turtule) {
		for (ICommand c : commands) {
			c.execute(turtule);
		}
	}

}
