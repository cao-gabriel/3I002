package pobj.tme6;

import javafx.scene.paint.Color;

public class SaveTurtle implements IColorTurtle {

	private CommandList buffer;
	
	public SaveTurtle() {
		buffer = new CommandList();
	}

	public CommandList getCommand() {
		return buffer;
	}
	
	@Override
	public void move(int length) {
		buffer.addCommand(new CommandMove(length));
	}

	@Override
	public void turn(int angle) {
		buffer.addCommand(new CommandTurn(angle));
	}

	@Override
	public void up() {
		buffer.addCommand(new CommandUp());
	}

	@Override
	public void down() {
		buffer.addCommand(new CommandDown());
	}

	@Override
	public void setColor(Color color) {
		buffer.addCommand(new CommandSetColor(color));
	}

}
