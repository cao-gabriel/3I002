package pobj.tme6;

public class SubstTurtle extends SaveTurtle {

	private ICommand subst;
	
	public SubstTurtle(ICommand subst)
	{ this.subst = subst; }

	@Override public void move(int length) {
		getCommand().addCommand(subst);
	}

}
