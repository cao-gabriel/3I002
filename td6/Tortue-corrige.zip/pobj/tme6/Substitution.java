package pobj.tme6;

public class Substitution {

	static public ICommand substitute(ICommand org, final ICommand subst) {
		SubstTurtle s = new SubstTurtle(subst);
		org.execute(s);
		return s.getCommand();
	}
}
