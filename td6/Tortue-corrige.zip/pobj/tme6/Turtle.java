package pobj.tme6;

public class Turtle implements ITurtle {

	private int x;
	private int y;
	private int angle;
	private boolean isDown;
	
	public Turtle() {
		isDown = true;
	}
	
	void draw(int x1, int y1, int x2, int y2) {
		System.out.println(x1 + " " + y1 + " " + x2 + " " + y2);
	}
	
	@Override
	public void move(int length) {
		int newX = x + (int)(length * Math.sin(angle * Math.PI / 180.));
		int newY = y + (int)(length * Math.cos(angle * Math.PI / 180.));
		if (isDown) {
			draw(x, y, newX, newY);
		}
		x = newX;
		y = newY;
	}

	@Override
	public void turn(int angle) {
		this.angle += angle;
	}

	@Override
	public void up() {
		isDown = false;
	}

	@Override
	public void down() {
		isDown = true;
	}

	
	// Accesseurs, permettant de garder les attributs privés
	
	public int getX() { return x; }
	public int getY() { return y; }
	public int getAngle() { return angle; }
	public boolean isDown() { return isDown; }
	
	void setX(int x) { this.x = x; }
	void setY(int y) { this.y = y; }
	
}
